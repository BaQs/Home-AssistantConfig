## 0.1.0
Fixed problems when scrolling and implemented fixed positioning

## 0.0.1
Initial release that supports versioning