## 0.0.2
Fix for card dissapearing when switching tabs

## 0.0.1
Initial release that supports versioning