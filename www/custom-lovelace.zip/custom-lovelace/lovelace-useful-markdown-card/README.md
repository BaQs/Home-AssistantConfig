useful-markdown-card
====================

```yaml
      - type: custom:useful-markdown-card
        content: >
          ## Lovelace

          Starting with Home Assistant 0.72, we're experimenting with a new way of defining your interface. We're calling it the **Lovelace UI**

          Also, the current time is [[ sensor.time.state ]] [[ sensor.time.attributes.icon]].
```

![useful-markdown-card](https://user-images.githubusercontent.com/1299821/44176410-fbf8a280-a0e9-11e8-88e3-74ad72434865.png)


---

Options:

- `padding` -  Adjust padding of markdown card (default `'16px'`)
- `fontSize` -  Adjust font-size of markdown card 
