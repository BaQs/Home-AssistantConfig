## 0.2.0
- Add support for custom unit of measurement

## 0.1.0
- support attributes

## 0.0.1
Initial release that supports versioning
